/**
 * Created by bizplay on 2017-08-05.
 */
public class Example_5 {
    public static void main(String[] args) {
        // 연습5
        double a = 9999999999999999d;
        System.out.println(a);
        int b = (int)a;
        System.out.println(b);
        System.out.println(Integer.MAX_VALUE);
    }
}
