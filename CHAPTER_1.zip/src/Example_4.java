/**
 * Created by bizplay on 2017-08-05.
 */
public class Example_4 {
    public static void main(String[] args) {
        // 연습4
        System.out.println(Double.MAX_VALUE);
        System.out.println(Double.MIN_VALUE);
        System.out.println(Math.nextUp(Double.MAX_VALUE));
        System.out.println(Math.nextUp(Double.MIN_VALUE));
    }
}
