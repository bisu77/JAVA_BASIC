/**
 * Created by bizplay on 2017-08-05.
 */
public class Example_7 {
    public static void main(String[] args) {
        // 연습7
        /*
         * 65,535 값을 short 변수로 못받아들임...
         */
        /*Scanner sc = new Scanner(System.in);
        System.out.println("0~65,535 숫자 2개를 입력하세요.");

        String str = sc.nextLine();
        String[] strArray = str.split(" ");
        if(strArray.length>2){
            System.out.println("숫자 2개를 입력하셔야 합니다.");
            return ;
        }
        for(int i=0;i<strArray.length;i++){
            // number[i] = Short.toUnsignedInt(strArray[i]);
        }

        System.out.println("합계 : " + (short)(number[0] + number[1]));
        System.out.println("차이 : " + (short)(number[0] - number[1]));
        System.out.println("곱 : " + (short)(number[0] * number[1]));
        System.out.println("몫 : " + (short)(number[0] / number[1]));
        System.out.println("나머지 : " + (short)(number[0] % number[1]));*/
    }
}
